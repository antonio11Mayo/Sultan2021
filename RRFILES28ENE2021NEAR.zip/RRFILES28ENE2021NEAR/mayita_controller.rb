class MayitaController < ApplicationController
  def index
  end   
end