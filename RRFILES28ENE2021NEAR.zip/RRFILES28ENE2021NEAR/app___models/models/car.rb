class Car < ApplicationRecord
end